package org.employee.db.salary;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.employee.db.Base;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigDecimal;
@Entity
@Table(name = "salary")
@Data
@EqualsAndHashCode(callSuper = true) // 부모 클래스의 필드를 가져다 쓸 경우에는, true 값을 준다.
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Salary extends Base{
    // 사원 = { department(부서), name, age, gender, phoneNumber, address , Business Hierarchy(직급)}
    // 급여 = {salary} 일일 급여.
    // 월급 = {monthSalary = salary * day(30)}
    // 연봉 = {annualSalary} = {(monthSalary * 12)}
    // 며칠 일 했는가 = {day}
    // 몇 시간씩 일 했는가 = {time}
    // 주휴수당 = {5일 일하면 하루 근무한 급여로 친다. + fiveAndAOneDay }
    // 연간 판매 금액 = {annualSalesAmount}
    // 성과금 = {performanceBonus = annualSalesAmount * 0.03}
    // 만약 성과금이 있다는 전제 하의 연봉 = {annualSalary} = {(monthSalary * 12) + performanceBonus}
    // 만약 보너스가 있다면 이유 없이 주는 보너스 = {incentive}
    @Column(nullable = false)
    private Long employeeId;
    private int time;
    private int day;
    @Column(precision = 11, scale = 4, nullable = false)
    private BigDecimal salary;
    @Column(precision = 11, scale = 4, nullable = false)
    private BigDecimal monthSalary;
    @Column(precision = 11, scale = 4, nullable = false)
    private BigDecimal annualSalary;
    @Column(precision = 11, scale = 4)
    private BigDecimal annualSalesAmount;
    @Column(precision = 11, scale = 4)
    private BigDecimal performanceBonus;

}
