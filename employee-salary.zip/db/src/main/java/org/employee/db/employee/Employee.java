package org.employee.db.employee;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.employee.db.Base;
import org.employee.db.employee.enums.EmployeeStatus;

import javax.persistence.*;
import java.math.BigDecimal;
@Entity
@Table(name = "employee")
@Data
@EqualsAndHashCode(callSuper = true) // 부모 클래스의 필드를 가져다 쓸 경우에는, true 값을 준다.
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class Employee extends Base {
    @Column(length = 100, nullable = false)
    private String department;
    @Column(length = 50, nullable = false)
    private String name;
    @Column(length = 50, nullable = false)
    private String age;
    @Column(length = 50, nullable = false)
    private String gender;
    @Column(length = 50, nullable = false)
    private String phoneNumber;
    @Column(length = 50, nullable = false)
    @Enumerated(EnumType.STRING)
    private EmployeeStatus employeeStatus;
    @Column(length = 100, nullable = false)
    private String address;
    @Column(length = 100, nullable = false)
    private String businessHierarchy;
}
