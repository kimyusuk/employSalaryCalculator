package org.employee.db.salary;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SalaryRepository extends JpaRepository<Salary, Long> {
    Salary findFirstByEmployeeIdOrderByIdDesc(Long employeeId);

}
