package org.employee.common.exception;


import org.employee.common.error.ErrorCodeIfs;

public interface ApiExceptionIfs {
    ErrorCodeIfs getErrorCodeIfs();

    String getErrorDescription();
}
