package org.employee.domain.salary.controller;

import lombok.RequiredArgsConstructor;
import org.employee.common.api.Api;
import org.employee.domain.employee.model.EmployeeRegisterRequest;
import org.employee.domain.employee.model.EmployeeResponse;
import org.employee.domain.salary.business.SalaryBusiness;
import org.employee.domain.salary.model.SalaryCalculatorRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/open-api/salary")
@RequiredArgsConstructor
public class SalaryOpenApiController {
    private final SalaryBusiness salaryBusiness;
    @PostMapping()
    public Api<EmployeeResponse> salaryCalculating(@Valid @RequestBody Api<SalaryCalculatorRequest> request) {
        var response = salaryBusiness.salaryCalculating(request.getBody());
        return Api.OK(response);
    }
}
