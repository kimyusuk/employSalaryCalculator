package org.employee.domain.employee.converter;

import lombok.RequiredArgsConstructor;
import org.employee.common.annotation.Converter;
import org.employee.common.error.ErrorCode;
import org.employee.common.exception.ApiException;
import org.employee.domain.employee.model.EmployeeRegisterRequest;
import org.employee.domain.employee.model.EmployeeResponse;
import org.employee.db.employee.Employee;
import org.employee.domain.salary.service.SalaryService;

import java.util.Optional;

@Converter
@RequiredArgsConstructor
public class EmployeeConverter {
    private final SalaryService salaryService;
    public Employee toEntity(EmployeeRegisterRequest employeeRegisterRequest) {
        return Optional.ofNullable(employeeRegisterRequest)
                .map(it -> Employee.builder()
                        .department(it.getDepartment())
                        .name(it.getName())
                        .age(it.getAge())
                        .gender(it.getGender())
                        .phoneNumber(it.getPhoneNumber())
                        .address(it.getAddress())
                        .businessHierarchy(it.getBusinessHierarchy())
                        .build())
                .orElseThrow(() -> new ApiException(ErrorCode.NULL_POINT, "EmployeeRegisterRequest Null"));
    }

    public EmployeeResponse toResponse(Employee employee) {
        return Optional.ofNullable(employee)
                .map(it -> EmployeeResponse.builder()
                        .id(it.getId())
                        .department(it.getDepartment())
                        .name(it.getName())
                        .age(it.getAge())
                        .gender(it.getGender())
                        .employeeStatus(it.getEmployeeStatus())
                        .phoneNumber(it.getPhoneNumber())
                        .address(it.getAddress())
                        .businessHierarchy(it.getBusinessHierarchy())
                        .build())
                .orElseThrow(() -> new ApiException(ErrorCode.NULL_POINT, "EmployeeRegisterRequest Null"));
    }

}
