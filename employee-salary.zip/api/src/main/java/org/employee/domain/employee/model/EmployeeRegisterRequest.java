package org.employee.domain.employee.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeRegisterRequest {
    @NotBlank
    private String department;
    @NotBlank
    private String name;
    @NotBlank
    private String age;
    @NotBlank
    private String gender;
    @NotBlank
    private String phoneNumber;
    @NotBlank
    private String address;
    @NotBlank
    private String businessHierarchy;
}
