package org.employee.domain.employee.model;
import lombok.*;
import org.employee.db.employee.enums.EmployeeStatus;

import java.math.BigDecimal;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeResponse {
    private Long id;
    private String department;
    private String name;
    private String age;
    private String gender;
    private EmployeeStatus employeeStatus;
    private String phoneNumber;
    private String address;
    private String businessHierarchy;

}
