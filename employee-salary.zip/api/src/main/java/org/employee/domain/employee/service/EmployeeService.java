package org.employee.domain.employee.service;

import lombok.RequiredArgsConstructor;
import org.employee.common.error.ErrorCode;
import org.employee.common.exception.ApiException;
import org.employee.domain.employee.converter.EmployeeConverter;
import org.employee.domain.employee.model.EmployeeRegisterRequest;
import org.employee.domain.employee.model.EmployeeResponse;
import org.employee.db.employee.Employee;
import org.employee.db.employee.EmployeeRepository;
import org.employee.db.employee.enums.EmployeeStatus;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class EmployeeService {
    private final EmployeeRepository employeeRepository;

    public Employee register(Employee employee) {
        return Optional.ofNullable(employee)
                .map(it->{
                    it.setEmployeeStatus(EmployeeStatus.REGISTERED);
                    return employeeRepository.save(it);})
                .orElseThrow(() -> new ApiException(ErrorCode.NULL_POINT, "Employee isNull"));
    }



}
