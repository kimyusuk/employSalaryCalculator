package org.employee.domain.employee.controller;

import lombok.RequiredArgsConstructor;
import org.employee.common.api.Api;
import org.employee.domain.employee.business.EmployeeBusiness;
import org.employee.domain.employee.model.EmployeeRegisterRequest;
import org.employee.domain.employee.model.EmployeeResponse;
import org.employee.domain.employee.service.EmployeeService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.math.BigDecimal;

@RestController
@RequestMapping("/open-api/employee")
@RequiredArgsConstructor
public class EmployeeOpenApiController {
    private final EmployeeBusiness employeeBusiness;
    @PostMapping("/register")
    public Api<EmployeeResponse> register(@Valid @RequestBody Api<EmployeeRegisterRequest> request) {
        var response = employeeBusiness.register(request.getBody());
        return Api.OK(response);
    }
}
