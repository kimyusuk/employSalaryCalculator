package org.employee.domain.salary.business;

import lombok.RequiredArgsConstructor;
import org.employee.common.annotation.Business;
import org.employee.domain.salary.converter.SalaryConverter;
import org.employee.domain.salary.model.SalaryCalculatorRequest;
import org.employee.domain.salary.model.SalaryResponse;
import org.employee.domain.salary.service.SalaryService;

import java.util.List;

@Business
@RequiredArgsConstructor
public class SalaryBusiness{
    private final SalaryService salaryService;
    private final SalaryConverter salaryConverter;

    public SalaryResponse salaryCalculating(SalaryCalculatorRequest salaryCalculatorRequest) {
        var entity = salaryConverter.toEntity(salaryCalculatorRequest);
        var savedEntity = salaryService.salaryCalculating(entity); // save 영역
        var response = salaryConverter.toResponse(savedEntity);
        return response;
    }
}
