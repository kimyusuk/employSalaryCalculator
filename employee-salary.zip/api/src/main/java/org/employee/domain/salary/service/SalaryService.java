package org.employee.domain.salary.service;

import lombok.RequiredArgsConstructor;
import org.employee.common.error.ErrorCode;
import org.employee.common.exception.ApiException;
import org.employee.db.salary.Salary;
import org.employee.db.salary.SalaryRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class SalaryService {
    private final SalaryRepository salaryRepository;

    public Salary salaryCalculating(Salary salary) {
        return Optional.ofNullable(salary)
                .map(it->salaryRepository.save(it))
                .orElseThrow(() -> new ApiException(ErrorCode.NULL_POINT, "Salary isNull"));

    }

    public Salary salaryFindByEmployeeId(Long employeeId) {
        return salaryRepository.findFirstByEmployeeIdOrderByIdDesc(employeeId);
    }
}
