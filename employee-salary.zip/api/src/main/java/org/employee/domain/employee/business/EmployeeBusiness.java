package org.employee.domain.employee.business;

import lombok.RequiredArgsConstructor;
import org.employee.common.annotation.Business;
import org.employee.domain.employee.converter.EmployeeConverter;
import org.employee.domain.employee.model.EmployeeRegisterRequest;
import org.employee.domain.employee.model.EmployeeResponse;
import org.employee.domain.employee.service.EmployeeService;
@Business
@RequiredArgsConstructor
public class EmployeeBusiness {
    private final EmployeeService employeeService;
    private final EmployeeConverter employeeConverter;
    public EmployeeResponse register(EmployeeRegisterRequest request) {
        var entity = employeeConverter.toEntity(request);
        var savedEntity = employeeService.register(entity); // save 영역
        var response = employeeConverter.toResponse(savedEntity);
        return response;
    }
}
