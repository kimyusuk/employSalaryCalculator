package org.employee.domain.salary.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalaryResponse {
    private Long employeeId;
    private int time;
    private int day;
    private BigDecimal salary;
    private BigDecimal monthSalary;
    private BigDecimal annualSalary;
    private BigDecimal annualSalesAmount;
    private BigDecimal performanceBonus;
}
