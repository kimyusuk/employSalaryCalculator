package org.employee.domain.salary.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SalaryCalculatorRequest {
    @NotNull
    private Long employeeId;
    @NotNull
    private BigDecimal time; // 시간
    @NotNull
    private BigDecimal hourlyRate; // 시급
    @NotNull
    private BigDecimal day; // 일수
    @NotNull
    private BigDecimal month; // 월수
}
