package org.employee.domain.salary.converter;

import lombok.RequiredArgsConstructor;
import org.employee.common.annotation.Converter;
import org.employee.db.salary.Salary;
import org.employee.domain.salary.model.SalaryCalculatorRequest;
import org.employee.domain.salary.model.SalaryResponse;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.BinaryOperator;

@Converter
@RequiredArgsConstructor
public class SalaryConverter {

    public Salary toEntity(SalaryCalculatorRequest salaryCalculatorRequest) {
        var dailySalary = List.of(salaryCalculatorRequest.getHourlyRate(), salaryCalculatorRequest.getTime())
                .stream().reduce(BigDecimal::multiply);
        var monthlySalary = List.of(salaryCalculatorRequest.getHourlyRate(), salaryCalculatorRequest.getTime(), salaryCalculatorRequest.getDay())
                .stream().reduce(BigDecimal::multiply);
        var annuallySalary = List.of(salaryCalculatorRequest.getHourlyRate(), salaryCalculatorRequest.getTime(), salaryCalculatorRequest.getDay(), salaryCalculatorRequest.getMonth())
                .stream().reduce(BigDecimal::multiply);
        return Salary.builder()
                .employeeId(salaryCalculatorRequest.getEmployeeId())
                .day(salaryCalculatorRequest.getDay().intValue())
                .time(salaryCalculatorRequest.getTime().intValue())
                .salary(dailySalary.get())
                .monthSalary(monthlySalary.get())
                .annualSalary(annuallySalary.get())
                .build();
    }

    public SalaryResponse toResponse(Salary salary) {
        return SalaryResponse.builder()
                .employeeId(salary.getEmployeeId())
                .day(salary.getDay())
                .time(salary.getTime())
                .salary(salary.getSalary())
                .monthSalary(salary.getMonthSalary())
                .annualSalary(salary.getAnnualSalary())
//                .annualSalesAmount(salary.getAnnualSalesAmount())
//                .performanceBonus(salary.getPerformanceBonus())
                .build();
    }
}
