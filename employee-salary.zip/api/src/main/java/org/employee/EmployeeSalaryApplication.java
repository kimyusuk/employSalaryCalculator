package org.employee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeSalaryApplication {
    public static void main(String[] args) {
        // 사원 급여 나눠주는 코드 작성해보기.
        SpringApplication.run(EmployeeSalaryApplication.class, args);

    }
}

